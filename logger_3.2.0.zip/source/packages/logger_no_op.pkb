create or replace
begin
*
ERROR at line 1:
ORA-24234: unable to get source of PACKAGE BODY "ALX"."LOGGER", insufficient privileges or does not exist
ORA-06512: at "SYS.DBMS_SYS_ERROR", line 150
ORA-06512: at "SYS.DBMS_PREPROCESSOR", line 191
ORA-06512: at "SYS.DBMS_PREPROCESSOR", line 109
ORA-06512: at line 2

https://docs.oracle.com/error-help/db/ora-24234/

/
